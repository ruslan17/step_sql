create function insert_user_2(name character varying, surname character varying, gender boolean)
  returns void
language plpgsql
as $$
BEGIN
  IF (surname = 'Stark')
  THEN
    INSERT INTO users (name, surname, gender)
    values ('John Stark', surname, gender);
  ELSEIF (surname = 'Snow')
    THEN
      INSERT INTO users (name, surname, gender)
      values ('John Snow', surname, gender);
  END IF;
END;
$$;


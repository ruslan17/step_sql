create function insert_user(name character varying, surname character varying, gender boolean)
  returns void
language plpgsql
as $$
BEGIN
  INSERT INTO users (name, surname, gender)
  values (name, surname, gender);
END;
$$;

